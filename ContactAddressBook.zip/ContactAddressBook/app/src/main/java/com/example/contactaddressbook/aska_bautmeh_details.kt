package com.example.contactaddressbook

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class aska_bautmeh_details : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aska_bautmeh_details)
        val homeButton2 = findViewById<Button>(R.id.homeBtn2)
        homeButton2.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

    }
}