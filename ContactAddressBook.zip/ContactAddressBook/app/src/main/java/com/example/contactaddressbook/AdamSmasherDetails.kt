package com.example.contactaddressbook

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class AdamSmasherDetails : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adam_smasher_details)
        val homeButton1 = findViewById<Button>(R.id.homeBtn1)
        homeButton1.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}