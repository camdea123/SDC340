package com.example.contactaddressbook

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val details1Button = findViewById<Button>(R.id.details1)
        details1Button.setOnClickListener {
            startActivity(Intent(this, AdamSmasherDetails::class.java))
        }
        val details2Button = findViewById<Button>(R.id.button2)
        details2Button.setOnClickListener {
            startActivity(Intent(this, aska_bautmeh_details::class.java))
        }
    }
}